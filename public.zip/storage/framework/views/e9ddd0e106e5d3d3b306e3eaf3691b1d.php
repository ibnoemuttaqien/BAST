<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Laporan Hasil</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
        }

        .container {
            width: 100%;
            margin: 0 auto;
            padding: 20px;
        }

        h1 {
            text-align: center;
            margin-bottom: 20px;
        }

        table {
            width: 100%;
            border-collapse: collapse;
            margin-bottom: 20px;
        }

        table,
        th,
        td {
            border: 1px solid #ddd;
        }

        th,
        td {
            padding: 8px;
            text-align: left;
        }

        th {
            background-color: #f4f4f4;
        }

        .filters {
            margin-bottom: 20px;
        }

        .filters p {
            margin: 0;
            font-weight: bold;
        }
    </style>
</head>

<body>
    <div class="container">
        <h1>Laporan Hasil</h1>

        <?php if($tanggalMulai && $tanggalAkhir): ?>
            <div class="filters">
                <p>Periode: <?php echo e($tanggalMulai); ?> - <?php echo e($tanggalAkhir); ?></p>
            </div>
        <?php endif; ?>

        <?php if($laporanHasil->isEmpty()): ?>
            <p>Tidak ada laporan hasil yang tersedia.</p>
        <?php else: ?>
            <table>
                <thead>
                    <tr>
                        <th>No</th>
                        <th>Nama Barang</th>
                        <th>Deskripsi</th>
                        <th>Kategori Pembuatan</th>
                        <th>Grade</th>
                        <th>Nama Pengguna</th>
                        <th>File</th>
                        <th>Tanggal</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $laporanHasil; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $laporan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($loop->iteration); ?></td>
                            <td><?php echo e($laporan->barang->nama); ?></td>
                            <td><?php echo e($laporan->deskripsi); ?></td>
                            <td><?php echo e($laporan->barang->kategoriPembuatan->nama ?? 'N/A'); ?></td>
                            <td><?php echo e($laporan->barang->kategoriGrade->nama ?? 'N/A'); ?></td>
                            <td><?php echo e($laporan->user->nama ?? 'N/A'); ?></td>
                            <td>
                                <?php if($laporan->file): ?>
                                    <a href="<?php echo e(asset($laporan->file)); ?>" target="_blank">View File</a>
                                <?php else: ?>
                                    N/A
                                <?php endif; ?>
                            </td>
                            <td><?php echo e($laporan->created_at->format('d-m-Y H:i:s')); ?></td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        <?php endif; ?>
    </div>
</body>

</html>
<?php /**PATH G:\SR Company\Project Nizar\nizar-web\resources\views/pdf/laporan_hasil.blade.php ENDPATH**/ ?>