<!DOCTYPE html>
<html>

<head>
    <meta charset="utf-8">
    <title>Laporan Absensi</title>
    <style>
        table {
            width: 100%;
            border-collapse: collapse;
        }

        th,
        td {
            padding: 8px;
            text-align: left;
            border: 1px solid #ddd;
        }

        th {
            background-color: #f2f2f2;
        }
    </style>
</head>

<body>
    <h1>Laporan Absensi</h1>
    <p>Karyawan: <?php echo e($karyawanId ? $karyawanId : 'Semua'); ?></p>
    <p>Periode: <?php echo e($tanggal ? $tanggal : ($tanggalMulai ? $tanggalMulai . ' - ' . $tanggalAkhir : 'Semua')); ?></p>

    <table>
        <thead>
            <tr>
                <th>No</th>
                <th>Nama Karyawan</th>
                <th>Foto</th>
                <th>Kehadiran</th>
                <th>Tanggal Masuk</th>
                <th>File</th>
                <th>Deskripsi</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $absensi; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($loop->iteration); ?></td>
                    <td><?php echo e($item->user->nama); ?></td>
                    <td>
                        <?php if($item->foto): ?>
                            <img src="<?php echo e(asset('absensi/' . $item->foto)); ?>" alt="Foto" width="100">
                            <a href="<?php echo e(asset('absensi/' . $item->foto)); ?>" target="_blank">Lihat
                                Foto</a>
                        <?php else: ?>
                            N/A
                        <?php endif; ?>
                    </td>

                    <td><?php echo e($item->kehadiran); ?></td>
                    <td><?php echo e($item->tanggal_masuk->format('d-m-Y H:i:s')); ?></td>
                    <td>
                        <?php if($item->file): ?>
                            <a href="<?php echo e(asset($item->file)); ?>" target="_blank">Lihat File</a>
                        <?php else: ?>
                            N/A
                        <?php endif; ?>
                    </td>
                    <td><?php echo e($item->deskripsi); ?></td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
</body>

</html>
<?php /**PATH G:\SR Company\Project Nizar\nizar-web\resources\views/pdf/absensi.blade.php ENDPATH**/ ?>