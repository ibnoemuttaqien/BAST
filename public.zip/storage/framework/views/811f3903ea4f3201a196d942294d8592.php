<!DOCTYPE html>
<html>

<head>
    <style>
        table {
            width: 100%;
            border-collapse: collapse;
        }

        th,
        td {
            padding: 8px;
            text-align: left;
            border: 1px solid #ddd;
        }

        th {
            background-color: #f2f2f2;
        }
    </style>
</head>

<body>
    <h1>Laporan Hasil Berdasarkan Karyawan</h1>

    <p>Karyawan: <?php echo e($karyawanId ? $karyawans->firstWhere('id', $karyawanId)->nama : 'Semua'); ?></p>
    <p>Periode: <?php echo e($tanggalMulai ? $tanggalMulai : 'Semua'); ?> - <?php echo e($tanggalAkhir ? $tanggalAkhir : 'Semua'); ?></p>

    <?php if($laporanHasil->isEmpty()): ?>
        <p>Tidak ada laporan hasil yang tersedia.</p>
    <?php else: ?>
        <table>
            <thead>
                <tr>
                    <th>No</th>
                    <th>Nama Barang</th>
                    <th>Deskripsi</th>
                    <th>Kategori Pembuatan</th>
                    <th>Grade</th>
                    <th>Nama Pengguna</th>
                    <th>File</th>
                    <th>Tanggal</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $laporanHasil; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $laporan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($loop->iteration); ?></td>
                        <td><?php echo e($laporan->barang->nama); ?></td>
                        <td><?php echo e($laporan->deskripsi); ?></td>
                        <td><?php echo e($laporan->barang->kategoriPembuatan->nama ?? 'N/A'); ?></td>
                        <td><?php echo e($laporan->barang->kategoriGrade->nama ?? 'N/A'); ?></td>
                        <td><?php echo e($laporan->user->nama ?? 'N/A'); ?></td>
                        <td>
                            <?php if($laporan->file): ?>
                                <a href="<?php echo e(Storage::url($laporan->file)); ?>" target="_blank">Lihat File</a>
                            <?php else: ?>
                                Tidak ada file
                            <?php endif; ?>
                        </td>
                        <td><?php echo e($laporan->created_at->format('d-m-Y H:i:s')); ?></td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    <?php endif; ?>
</body>

</html>
<?php /**PATH G:\SR Company\Project Nizar\nizar-web\resources\views/pdf/laporan_hasil_by_karyawan.blade.php ENDPATH**/ ?>